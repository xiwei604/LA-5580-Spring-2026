---
title: "About Me"
permalink: /about/
---

My name is **Your Name**.

This site documents my work for **LA5880**, including GIS exercises, assignments, and a final project.

I am a professor at Iowa State University, I majored in Landscape Architecture and much of my work 
focuses on data crowdsourcing, geospatial technology and data visualization. I am originally from North Dakota. etc. etc.
