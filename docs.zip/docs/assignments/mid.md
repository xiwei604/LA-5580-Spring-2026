---
title: "Mid Semester project"
permalink: /assignments/mid/
---

Mid Semester Project description

