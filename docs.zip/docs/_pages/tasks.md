---
title: "Tasks"
permalink: /tasks/
---

This section contains task-based assignments and embedded outputs.
