---
title: "Assignments"
permalink: /assignments/
---

Major graded assignments.
