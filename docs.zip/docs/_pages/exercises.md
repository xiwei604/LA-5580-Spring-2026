---
title: "Exercises"
permalink: /exercises/
---

Exercises completed throughout the course.
