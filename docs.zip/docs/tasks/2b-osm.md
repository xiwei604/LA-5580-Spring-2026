---
title: "2b OSM Embed"
permalink: /tasks/2b-osm/
markdown: false
---



<iframe width="425" height="350" src="https://www.openstreetmap.org/export/embed.html?bbox=-106.23178482055665%2C39.40701936950632%2C-105.90270996093751%2C39.557530079132086&amp;layer=mapnik&amp;marker=39.48231543921616%2C-106.06724739074707" style="border: 1px solid black"></iframe><br/><small><a href="https://www.openstreetmap.org/?mlat=39.48232&amp;mlon=-106.06725#map=13/39.48232/-106.06725">View Larger Map</a></small>