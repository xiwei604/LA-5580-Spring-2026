---
title: "3a Tableau Embedded Example 1"
permalink: /tasks/3a-tableau-embed1/
markdown: false
---

<div class='tableauPlaceholder' id='viz1769622254403' style='position: relative'>
  <noscript>
    <a href='#'>
      <img alt='Sheet 1'
           src='https://public.tableau.com/static/images/bi/birdPhotos/Sheet1/1_rss.png'
           style='border: none' />
    </a>
  </noscript>

  <object class='tableauViz' style='display:none;'>
    <param name='host_url' value='https%3A%2F%2Fpublic.tableau.com%2F' />
    <param name='embed_code_version' value='3' />
    <param name='site_root' value='' />
    <param name='name' value='birdPhotos/Sheet1' />
    <param name='tabs' value='no' />
    <param name='toolbar' value='yes' />
    <param name='language' value='en-US' />
  </object>
</div>

<script type='text/javascript'>
  var divElement = document.getElementById('viz1769622254403');
  var vizElement = divElement.getElementsByTagName('object')[0];
  vizElement.style.width='100%';
  vizElement.style.height=(divElement.offsetWidth*0.75)+'px';

  var scriptElement = document.createElement('script');
  scriptElement.src = 'https://public.tableau.com/javascripts/api/viz_v1.js';
  vizElement.parentNode.insertBefore(scriptElement, vizElement);
</script>