---
title: "2a QGIS JPEG"
permalink: /tasks/2a-jpg/
---

Below is a png image that was exported from QGIS. The map shows household income by county.

![Description of the image](/seeger5880-2026/assets/images/2a_household_income.png)




<img
  src="/seeger5880-2026/assets/images/2a_household_income.png"
  alt="Household income by county in Iowa"
  style="max-width: 800px; width: 100%; height: auto;"
/>

