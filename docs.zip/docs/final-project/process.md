---
title: "Final Project Process"
permalink: /final-project/process/
---

Here you will write about the process you used to create your final project.  You can and should use screenshots to document your progress. Even document things that did not work as planned that you may have had to go and do again.